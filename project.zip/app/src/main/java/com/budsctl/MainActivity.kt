package com.budsctl

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.UUID
import kotlin.concurrent.thread

// ===== СЮДА ВПИСАТЬ HEX-КОМАНДЫ ВАШЕЙ МОДЕЛИ, напр. "AA 01 02" =====
object P {
    val uuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    val cmd = mapOf(
        "anc" to "", "trans" to "", "off" to "",
        "eq0" to "", "eq1" to "", "eq2" to "", "eq3" to "",
        "game_on" to "", "game_off" to ""
    )
}

class Conn {
    var sock: BluetoothSocket? = null

    @SuppressLint("MissingPermission")
    fun connect(d: BluetoothDevice, log: (String) -> Unit, ok: () -> Unit) = thread {
        try {
            val s = d.createRfcommSocketToServiceRecord(P.uuid)
            s.connect(); sock = s; ok()
            val b = ByteArray(256)
            while (true) {
                val n = s.inputStream.read(b)
                if (n < 0) break
                log("← " + b.take(n).joinToString(" ") { "%02X".format(it) })
            }
        } catch (e: Exception) { log("✗ ${e.message}") }
    }

    fun send(hex: String, log: (String) -> Unit) {
        val h = hex.replace(" ", "")
        if (h.isEmpty() || h.length % 2 != 0) { log("команда не задана"); return }
        val s = sock ?: run { log("нет соединения"); return }
        thread {
            try {
                s.outputStream.write(ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() })
                log("→ $hex")
            } catch (e: Exception) { log("✗ ${e.message}") }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}

val BG = Color(0xFF000000)
val GR = Color(0xFF1C1C1C)
val RED = Color(0xFFD71921)

@Composable
fun T(t: String, s: Int = 14, c: Color = Color.White) =
    Text(t, color = c, fontSize = s.sp, fontFamily = FontFamily.Monospace)

@Composable
fun Pill(t: String, on: Boolean = false, f: () -> Unit) =
    Box(Modifier.clip(CircleShape).background(if (on) RED else GR).clickable { f() }.padding(16.dp, 10.dp)) { T(t, 13) }

fun key(ctx: Context, k: Int) {
    val a = ctx.getSystemService(AudioManager::class.java)
    a.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, k))
    a.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, k))
}

@SuppressLint("MissingPermission")
@Composable
fun App() {
    val ctx = LocalContext.current
    val conn = remember { Conn() }
    var granted by remember {
        mutableStateOf(Build.VERSION.SDK_INT < 31 ||
            ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == 0)
    }
    val req = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) req.launch(Manifest.permission.BLUETOOTH_CONNECT) }

    var devs by remember { mutableStateOf(listOf<BluetoothDevice>()) }
    LaunchedEffect(granted) {
        if (granted) devs = (ctx.getSystemService(BluetoothManager::class.java).adapter
            ?.bondedDevices ?: emptySet()).toList()
    }
    var sel by remember { mutableStateOf<BluetoothDevice?>(null) }
    var ok by remember { mutableStateOf(false) }
    var pop by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf(2) }
    var eq by remember { mutableStateOf(0) }
    var game by remember { mutableStateOf(false) }
    var hex by remember { mutableStateOf("") }
    var log by remember { mutableStateOf(listOf<String>()) }
    val add = { s: String -> log = (log + s).takeLast(6) }

    LaunchedEffect(pop) { if (pop) { delay(3000); pop = false } }
    val tr = rememberInfiniteTransition(label = "p")
    val sc by tr.animateFloat(1f, 1.35f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "s")

    Box(Modifier.fillMaxSize().background(BG)) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp, 48.dp, 20.dp, 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            T("BUDS CONTROL", 24)
            T(if (ok) "● ${sel?.name}" else "○ не подключено", 14, if (ok) RED else Color.Gray)
            T("УСТРОЙСТВО", 11, Color.Gray)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                devs.forEach { d ->
                    Pill(d.name ?: d.address, d == sel) {
                        sel = d
                        conn.connect(d, add) { ok = true; pop = true }
                    }
                }
            }
            T("ШУМОДАВ", 11, Color.Gray)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ANC" to "anc", "ПРОЗРАЧН." to "trans", "ВЫКЛ" to "off").forEachIndexed { i, (n, k) ->
                    Pill(n, mode == i) { mode = i; conn.send(P.cmd[k] ?: "", add) }
                }
            }
            T("ЭКВАЛАЙЗЕР", 11, Color.Gray)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Баланс", "Бас", "Голос", "Высокие").forEachIndexed { i, n ->
                    Pill(n, eq == i) { eq = i; conn.send(P.cmd["eq$i"] ?: "", add) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()) {
                T("ИГРОВОЙ РЕЖИМ")
                Switch(game, { game = it; conn.send(P.cmd[if (it) "game_on" else "game_off"] ?: "", add) },
                    colors = SwitchDefaults.colors(checkedTrackColor = RED))
            }
            T("МУЗЫКА", 11, Color.Gray)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("⏮") { key(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS) }
                Pill("⏯") { key(ctx, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }
                Pill("⏭") { key(ctx, KeyEvent.KEYCODE_MEDIA_NEXT) }
            }
            T("ОТЛАДКА (hex)", 11, Color.Gray)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(hex, { hex = it }, Modifier.weight(1f), singleLine = true, placeholder = { T("AA 01 02", 13, Color.Gray) })
                Pill("SEND") { conn.send(hex, add) }
            }
            log.forEach { T(it, 11, Color.Gray) }
        }

        AnimatedVisibility(
            pop, Modifier.align(Alignment.BottomCenter).padding(16.dp),
            enter = slideInVertically { it } + fadeIn() + scaleIn(initialScale = 0.8f),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(GR).padding(20.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(Modifier.size(48.dp).scale(sc).border(3.dp, RED, CircleShape))
                Column { T("ПОДКЛЮЧЕНО", 12, RED); T(sel?.name ?: "", 18) }
            }
        }
    }
}
